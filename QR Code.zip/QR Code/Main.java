import java.awt.Component;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
public class Main{

    public static void main(String[] args) {
        Frame frame = new Frame();
        frame.add(new CustomPaintMethod());
        frame.setSize(11,10);
    }
}